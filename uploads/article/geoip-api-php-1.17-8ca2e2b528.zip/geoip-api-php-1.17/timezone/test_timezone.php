#!/usr/bin/php -q
<?php
require("timezone.php");
print get_time_zone("US", "WV");
?>
